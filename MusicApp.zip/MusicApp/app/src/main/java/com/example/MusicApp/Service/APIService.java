package com.example.MusicApp.Service;

public class APIService {
    private static String base_url = "https://18521013.000webhostapp.com/Server/";
    public static Dataservice getService(){
        return APIRetrofitClient.getClient(base_url).create(Dataservice.class);
    }
}
